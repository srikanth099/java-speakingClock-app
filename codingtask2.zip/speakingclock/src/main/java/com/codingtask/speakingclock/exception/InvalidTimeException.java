package com.codingtask.speakingclock.exception;


public class InvalidTimeException extends Exception {
    public InvalidTimeException(String message) {
        super(message);
    }
}
